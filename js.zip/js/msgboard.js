jQuery(document).ready(function() {
	
	jQuery(".sharelink").click(function(){
		
		jQuery(this).select();
		
	});

	jQuery(".sharelink").change(function(){
	
		jQuery(this).val(jQuery('.sharelinkghost').html());
	
	});
	
	jQuery('#idc-commentcountlabel').css('font-size','15px');
	jQuery('#idc-commentcountlabel').css('font-weight','bold');
	
	jQuery('h3').css('font-size','15px');
	jQuery('h3').css('font-weight','bold');
	
	jQuery('div.idc').css('visibility','none');
	
	jQuery('#postFB').click(function(e){
	
		e.preventDefault();
		jQuery('#publishToFB').submit();
	
	});
	
	jQuery('#addimage2comment').click(function(e){
	
		e.preventDefault();
		var imgURL=prompt("Enter Image URL","http://");
		if(imgURL.length > 9) {
		jQuery('.idc-text_noresize').val(jQuery('.idc-text_noresize').val()+"<img src='"+imgURL+"' />");
		}
	});
	
	jQuery('#addlink2comment').click(function(e){
	
		e.preventDefault();
		var imgURL=prompt("Enter Link URL","http://");
		if(imgURL.length > 9) {
		jQuery('.idc-text_noresize').val(jQuery('.idc-text_noresize').val()+"<a href='"+imgURL+"'>"+imgURL+"</a>");
		}
	});
	
	setInterval(function(){
	
		jQuery('#idc-commentcountlabel').html("Tributes");
	
	}, 500);
	
	function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=650,width=850,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}

	jQuery(".pdflink").click(function(e){
		
		e.preventDefault();
		newPopup(jQuery(this).attr('href'));
	
	});
	
	tinyMCE.init({
        mode : "textareas",
		elements: "tribute_content",
		theme : "advanced",
		theme_advanced_toolbar_location : "top",
		theme_advanced_buttons1 : "undo, redo,separator,bold,italic,underline,strikethrough,zoom,separator,justifyleft, justifyright,justifycenter,formatselect,separator,bullist,numlist,separator,forecolor,backcolor,separator,link,unlink,image",
		theme_advanced_buttons2 : "",
		theme_advanced_buttons3 : ""
	});
	
	jQuery('#publish_button').click(function(e){
	
		e.preventDefault();
		jQuery('#postTribute').submit();
	
	});
	
	jQuery("#facebook-share-btn").click(function(e) {
		e.preventDefault();
		var url = window.location.href;
		var image = "#"
		if(jQuery("#image-fb-share").length > 0)
			image = jQuery("#image-fb-share").text();
		var desc = document.title;
		if(jQuery(".desc").length > 0)
			desc = jQuery(".desc").text();
		window.open("http://www.facebook.com/sharer.php?s=100&p[url]="+url+"&p[images][0]="+image+"&p[title]="+encodeURIComponent(document.title)+"&p[summary]="+desc);
	});
	
});