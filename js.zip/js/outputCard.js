jQuery(document).ready(function(){

	jQuery("#continue_button").click(function(e){
		
		e.preventDefault();
	
		check();
	
	});
	
	function check() {
		
		var makeboardValue = "no";

		if(jQuery("input[name='makeboard']").attr('checked')) {
			
			makeboardValue = "yes";
		
		}
		
		if(jQuery("textarea[name='recipients']").val() == ""){
		
			jQuery(".alertmsg").html("You must input at least 1 email address.");
		
		}
		
	
		var hasInvalid = false;
		
		if(echeck(jQuery("input[name='email']").val())==false) {
			if(jQuery("input[name='email']").val()!="") {
				jQuery(".alertmsg").html("Invalid email: "+jQuery("input[name='email']").val());
			} else {
				jQuery(".alertmsg").html("Please enter your email address.");
			}
			hasInvalid = true;
		}
		
		
		
		var emails = jQuery("textarea[name='recipients']").val();
		
		var emailArray = emails.split(" ");
		
		var wrongEmail = "";
		
		jQuery.each(emailArray, function(i, val){
			
			if(echeck(val)==false) {
				wrongEmail += (val+" ");
				hasInvalid = true;
			}
		
		});
		
		if(jQuery("textarea[name='recipients']").val() != "" && !hasInvalid) {
		
			jQuery("input[name='makeboardghost']").val(makeboardValue);
			jQuery("#customconfirm").submit();
	
		}else {
			jQuery(".alertmsg").html("Invalid or missing email address/es!"+wrongEmail);

		}
	
	}
	
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   
		   return false
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   
		   return false
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    
		    return false
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    
		    return false
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    
		    return false
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    
		    return false
		 }
		
		 if (str.indexOf(" ")!=-1){
		    
		    return false
		 }

 		 return true					
	}

	function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=650,width=850,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}

	jQuery(".pdflink").click(function(e){
		
		e.preventDefault();
		newPopup(jQuery(this).attr('href'));
	
	});
	
});