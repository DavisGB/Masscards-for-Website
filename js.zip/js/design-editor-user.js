jQuery(document).ready(function(){
	
	var x= 5;
    var y = 1;
    var sid = getUrlParameter('sid');
    var cat_id = getUrlParameter('cat');
	jQuery(".field").each(function() {
		
		var name = jQuery(this).attr("name");
		var x_coord = jQuery(this).attr("x");
		var y_coord = jQuery(this).attr("y");
		var width = jQuery(this).attr("width");
        var height = jQuery(this).attr("height");
        
	
		if(jQuery("#design_form").length==0){
		
			jQuery(".imgholder").append("<form id='design_form'></form>");
		
		}
		
		if(x_coord == '-1' && y_coord == '-1'){
			x_coord = x;
			y_coord = y*25;
			y++;
		}
		
		jQuery("#design_form").append("<div class='field-replica' id='"+name+"' name='"+name+"' style='position: absolute;left: "+x_coord+"px;top: "+y_coord+"px;width: "+width+"px;height: "+height+"px'>"+name+"</div>");
		jQuery("#"+name).draggable();
		jQuery("#"+name).resizable({handles: "n, e, s, w"});
	});
	
	jQuery('.field-replica').mouseup(function(){
	
		var newY = jQuery(this).offset().top-jQuery('.editor').offset().top;
		var newX = jQuery(this).offset().left-jQuery('.editor').offset().left;
		var newWidth = jQuery(this).width();
		var newHeight = jQuery(this).height();
		var name = jQuery(this).attr("name");
		
		jQuery("div[name*='"+name+"']").attr("x", newX);
		jQuery("div[name*='"+name+"']").attr("y", newY);
		jQuery("div[name*='"+name+"']").attr("width", newWidth);
		jQuery("div[name*='"+name+"']").attr("height", newHeight);
		
		var design_id = jQuery('#att').attr("design");
		
		var params = "design="+design_id+"&cat="+cat_id+"&sid="+sid;
		jQuery(".field").each(function() {
		
			var name = jQuery(this).attr("name");
			var x_coord = jQuery(this).attr("x");
			var y_coord = jQuery(this).attr("y");
			var width = jQuery(this).attr("width");
			var height = jQuery(this).attr("height");
		
			params += "&"+name+"name="+name;
			params += "&"+name+"x_coord="+x_coord;
			params += "&"+name+"y_coord="+y_coord;
			params += "&"+name+"width="+width;
			params += "&"+name+"height="+height;
		
		});
		
		setLink(params);
	});

	function setLink(params){
	
		jQuery("#updatefields").attr("href", "saveFieldsCustom.php?"+params);
	
	}
	
});

var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};