jQuery(document).ready(function(){

	jQuery('#adduser-button').click(function(e){
	
		e.preventDefault();
		if(jQuery("input[name$='username']").val().length == 0 || jQuery("input[name$='password']").val().length == 0){
			jQuery(".errormsg").html("Enter a username and password for the new user");
		}else {
			jQuery('#add').submit();
		}
	});
	
	jQuery('#updateuser-button').click(function(e){
	
		e.preventDefault();
		
		if(jQuery("input[name$='username']").val().length == 0 || jQuery("input[name$='password']").val().length == 0){
			jQuery(".errormsg").html("Never leave the username and password blank.");
		}else {
			jQuery('#update').submit();
		}
	
	});
	
});