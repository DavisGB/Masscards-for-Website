<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Mass Cards|Confirm</title>
		<link href="css/outputPage.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/outputCard2.js?<?php echo date('l jS \of F Y h:i:s A'); ?>"></script>
		<script type='text/javascript' src='js/tiny_mce/tiny_mce.js'></script>
		<script type='text/javascript' src="js/mce.js?<?php echo date('l jS \of F Y h:i:s A'); ?>"></script>
		
	</head>
	<body>
		<center><img id="phjlogo" src="phjesuitslogo.png" /></center>
		<div class="container">
			<p class='intro'><b>Step 5 of 6</b></p>
			<h4>CONFIGURE YOUR ONLINE TRIBUTE BOARD</h4>
			<p class='intro2'>Do you want to enable a message wall? Your friends and loved ones can post tributes on this board and even upload pictures to honor the person for whom you are offering a Mass. This is a free service provided by the Philippine Jesuits. We will send you a link to this board, and you and your friends can visit it for one year starting today. After one year, the board will be disabled.</p>
			<?php
			
				require_once('impt.php');
				
				$design_id = $_GET['design']; 
				$card_id = $_GET['card'];
				
				mysql_connect($server,$username,$password);
				
				@mysql_select_db($database) or die( "Unable to select database");
				
				if($design_id && $card_id) {
				
					$query="SELECT * FROM mc_masscards WHERE id=".$card_id;
					$result=mysql_query($query);
					
					$num=mysql_numrows($result);
					
					if($num>0) {
					
						$imageURL = mysql_result($result,0,"img_url");
						
						mysql_query("INSERT INTO mc_boards (title, description, masscard_id, include_card, deleted) VALUES ('An Online Tribute', '', ".$card_id.", TRUE, FALSE)");
						$board_id = mysql_insert_id();
						
						echo "<div class='confirm_details'>";
						echo "<p class='intro'>";
						echo "Sample of an online Tribute Board: ";
						//echo "When you click it you will be forced out of this page, so it is important that you open the link in a new tab or window, or just press the back button of your browser.";
						echo "</p>";
						//echo "<p><a class='link pdflink' id='thepdf' href='".$imageURL."'>Click here to see your card [PDF Format]</a></p>";
						echo "<p></p>";
						//echo "<p><a class='link' href='customizeDesign.php?design=".$design_id."'>Or click here to re-edit your card</a></p>";
						
						//echo "<br />";
						//echo "<p class='intro'>Know that you can send this card in an email to people that you know. Additionally, you can create a custom personal message board about the card for people to comment on.</p>";
						
						echo "<div class='custompage'>";
						
						//form
						echo "<form  enctype='multipart/form-data' id='msgboardedit' action='msgboardProcessor2.php' method='POST'>";
						/**echo "<br /><p class='label'>Enter your full name:</p>";
						echo "<p><input type='text' name='sender' /></p>";
						echo "<br /><p class='label'>Enter your Email:</p>";
						echo "<p><input type='text' name='email' /></p>";
						echo "<br /><p class='label'>Email this card to:</p>";
						echo "<p><textarea name='recipients'></textarea><br /><span class='note'>*Use spaces to separate multiple email addresses</span></p>";
						echo "<br /><p class='label'>Write a message in the email:</p>";
						echo "<p><textarea name='msg'></textarea><br /></p>";
						echo "<p><input type='checkbox' name='makeboard' value='yes' checked='true' /> <span class='checkboxlabel'>Make a personal message board for them to comment on</span></p>";
						echo "<p style='display: none'><input name='card' type='text' value='".$card_id."' /></p>";
						echo "<p style='display: none'><input name='imageURL' type='text' value='".$imageURL."' /></p>";
						echo "<p style='display: none'><input name='makeboardghost' type='text' value='' /></p>";
						**/
						echo "<input id='creator' type='radio' name='group1' value='Yes'><span style='font-size: 12px'>Yes, please set up this FREE online tribute board!</span><br>";
						echo "<input type='radio' name='group1' value='No' checked><span style='font-size: 12px'>No need. Thank you for the offer.</span><br>";
						echo "<br /><p class='label'>Your Message Board Details</p><br />";
						echo "<br /><p class='label'>Title:</p>";
						echo "<p><input class='title ff' disabled='disabled' name='title' style='width: 320px;' value='An Online Tribute' /><br /></p>";
						echo "<p class='label'>Description:</p>";
						echo "<p><textarea id='desc' class='ff' disabled='disabled' name='desc'></textarea>";
						//<a href='#' id='addimage2comment' class='goback2category' style='margin: 0px;margin-left: 0px; width: 100px; display: inline;'>Add Image</a> <a href='#' id='addlink2comment' class='goback2category' style='margin: 0px;width: 100px;margin-left: 30px; display: inline;'>Add Link</a><br /><br /><p><span class='note' style='display: block'>*Note that you can use HTML in this textbox. In this way, you can add images and links.</span></p><br />";
						echo "</p>";
						echo "<br />";
						echo "<p style='font-size: 12px;' >Upload an image to display on your comment board or not (this image can be a picture of the person this mass card is for).<br /><span style='color: red;'>A note to the customer: if you do not have an image right now, images can be inserted later on--not on top of the page anymore but within the comments.</span></p>";
						//echo "<p><input type='checkbox' name='includecard' value='yes' checked='true' /> <span class='checkboxlabel'>Include the card PDF in the message board</span></p>";
						echo "<input type='hidden' name='MAX_FILE_SIZE' value='2000000' />";
						echo "<p><input name='image' type='file' class='ff' disabled='disabled' /> <span style='font-size: 12px;'>(Preffered Size: 400x400)</span></p>";
						echo "<br /><br />";
						echo "<p style='display: none'><input name='board' type='text' value='".$board_id."' /></p>";
						echo "<p style='display: none'><input name='imageURL' type='text' value='".$imageURL."' /></p>";
						echo "<p style='display: none'><input name='design' type='text' value='".$design_id."' /></p>";
						echo "<p style='display: none'><input name='card' type='text' value='".$card_id."' /></p>";
						echo "<p style='display: none'><input name='includecardghost' type='text' value='yes' /></p>";
						echo "</form>";
						echo "<p><span class='alertmsg'></span></p>";
						echo "</div>"; //email and custom page
						echo "</div>"; //confirm_details
					
					} else {
					
						//mass card not found
						header( "Location: error.php");
					
					}
				
				} else {
				
					//no design_id or card_id
					header( "Location: error.php");
				
				}
			
			?>
			<div class='instruction_container'>
				<span class='instruction_title'>Your Progress</span>
				<div class='instructions inactive'>
					<p>Step 1/5 - Choose the appropriate category from the left. Read the description for more information. Click the thumbnail or the category name to select it.
					</p>
				</div>
				<div class='instructions inactive'>
					<p>Step 2/5 - Examine and pick a design from the table on the left. You can click a design's thumbnail to make it larger. Click its name if you desire to select it.
					</p>
				</div>
				<div class='instructions inactive'>
					<p>Step 3/5 - Input text into the textboxes inside the card. You can align the text as you like it by filling it with spaces. Press "Click here to continue" to process your card.
					</p>
				</div>
				<div class='instructions active'>
					<p>Step 4/5 - Click the link given to see your card in PDF format. You can re-edit your card by clicking the link below it. You can send this card to people you know and make a message board as well. Press the button below to continue.
					</p>
				</div>
			</div>
			<a id='continue_button' class='goback2category' href='#'>Click here to Continue</a>
			<div style='clear: both'></div>
		</div>
	</body>
</html>