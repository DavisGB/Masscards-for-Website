jQuery(document).ready(function(){

	jQuery('#postFB').click(function(e){
	
		e.preventDefault();
		jQuery('#publishFB').submit();
	
	});

});