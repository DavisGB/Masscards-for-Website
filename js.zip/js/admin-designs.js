jQuery(document).ready(function(){

	jQuery('.a-image-thumb').lightBox();

	jQuery('#adddesign-button').click(function(e){
	
		e.preventDefault();
		if(jQuery("input[name$='image']").val().length == 0){
			jQuery(".errormsg").html("Make sure you have selected an image to upload");
		} else if(jQuery("input[name$='name']").val().length == 0 || jQuery("textarea[name$='desc']").val().length == 0 || jQuery("select[name$='category']").val().length == 0){
			jQuery(".errormsg").html("Enter name, description and category");
		}else {
			jQuery('#add').submit();
		}
	}); 
	
	jQuery('#updatedesign-button').click(function(e){
		
		e.preventDefault();
		
		if(jQuery("input[name$='image']").val().length == 0){
			jQuery("input[name$='imageghost']").val("retain");
		}else{
			jQuery("input[name$='imageghost']").val("change");
		}
		
		if(jQuery("input[name$='name']").val().length == 0 || jQuery("textarea[name$='desc']").val().length == 0){
			jQuery(".errormsg").html("Never leave the name and description blank");
		}else {
			jQuery('#update').submit();
		}
	
	});
	
});