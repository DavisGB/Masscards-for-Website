jQuery(window).load(function(){
	
	if(jQuery('.checker').html()=="None") {
	
		//no designs
		jQuery('.container').html("<h4>Design Not Found</h4>");
		jQuery('.container').append("<a class='goback2category' href='categories.php'>Click here to pick a category</a>");
	
	} else {
		/*
		jQuery(".imgholder").mousemove(function(event){
		
			var x = event.pageX - jQuery(".imgholder").offset().left;
			var y = event.pageY - jQuery(".imgholder").offset().top;

			jQuery(".x_coord").html(x);
			jQuery(".y_coord").html(y);
		
		});
		*/
		jQuery(".field").each(function() {
		
			var name = jQuery(this).attr("name");
			var x_coord = jQuery(this).attr("x");
			var y_coord = jQuery(this).attr("y");
			var width = jQuery(this).attr("width");
			var height = jQuery(this).attr("height");
			var fontSize = 14;
			
			// mobile correction 
			if(jQuery("#mobilecheck").length > 0) {
				// get width
				var mobileImgWidth = jQuery(".editor .imgholder img").width();
				x_coord = ( parseInt(x_coord)*mobileImgWidth ) / 700;
				y_coord = ( parseInt(y_coord)*mobileImgWidth ) / 700;
				width = ( parseInt(width)*mobileImgWidth ) / 700;
				height = ( parseInt(height)*mobileImgWidth ) / 700;
				fontSize = ( parseInt(fontSize)*mobileImgWidth ) / 700;
			}
			
		
			if(jQuery("#design_form").length==0){
			
				jQuery(".imgholder").append("<form id='design_form'></form>");
			
			}
			
			jQuery("#design_form").append("<div style='position: absolute;left: "+x_coord+"px;top: "+y_coord+"px;width: "+width+"px; height: "+height+"px'><textarea name='"+name+"' /></div>");
			jQuery("textarea[name='"+name+"']").css("width", width+"px");
			jQuery("textarea[name='"+name+"']").css("height", height+"px");
			
			// mobile correction 2
			if(jQuery("#mobilecheck").length > 0) {
				jQuery("textarea[name='"+name+"']").css("font-size", fontSize+"px");
			}
		
		});
		
		var card_width = jQuery(".imgholder img").width();
		var card_height = jQuery(".imgholder img").height();
		var	orig_height = jQuery(".origImage").height();
		var	orig_width = jQuery(".origImage").width();	
		
		jQuery(".fields").append("<div class='card_attr' width='"+card_width+"' height='"+card_height+"'>");
		
		//when input is changed
		jQuery("textarea").change(function() {
		
			var cwidth = jQuery(".imgholder img").width();
			var cheight = jQuery(".imgholder img").height();
			var oheight = jQuery(".origImage").height();
			var owidth = jQuery(".origImage").width();
			
			// mobile correction
			if(jQuery("#mobilecheck").length > 0) {
				cwidth = 700;
				cheight = (cwidth * oheight)/owidth;
			}
				
			var params = "design=" + jQuery(".desid").html();
			params += "&cat=" + jQuery(".cat").html();
			params += "&cheight=" + cheight;
			params += "&cwidth=" + cwidth;
			params += "&oheight=" + oheight;
			params += "&owidth=" + owidth;	
			
			jQuery("textarea").each(function() {
			
				params += "&" + jQuery(this).attr("name") + "=" + jQuery(this).val().replace("&", "%26%2338;").replace(/(?:\r\n|\r|\n)/g, '<br>');;
				
			});
		
			jQuery("#continue_button").attr("href", "processCard.php?"+params+"&sid="+jQuery(".sid").html());
			
		});
		
		jQuery("#continue_button").click(function(e) {
			
			/*
			if(jQuery(this).attr("href") == "#") {
				
				e.preventDefault();
				jQuery(".alertmsg").html("Please fill in both input boxes with the required information.");
			
			} else {
			
				return true;
			
			}*/
			
			var t = true;
			
			jQuery("textarea").each(function(){
			
				if(jQuery(this).val()=="") {
					
					t = false;
					
				}
			
			});
			
			if(t==true){
				return true;
			}else{
				e.preventDefault();
				jQuery(".alertmsg").html("Please fill in both input boxes with the required information.");
			
			}
			
		
		});
	
	}
  
	
	$('input, select, textarea').bind('blur', function(event) {
		$('meta[name=viewport]').attr('content', 'width=device-width,initial-scale=1,maximum-scale=1');
		$('meta[name=viewport]').attr('content', 'width=device-width,initial-scale=1,maximum-scale=10');
	});
	
});