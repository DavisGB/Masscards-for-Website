jQuery(document).ready(function(){

	jQuery('#submit').click(function(e){
	
		e.preventDefault();
		jQuery('#login').submit();
	
	});

});