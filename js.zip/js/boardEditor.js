jQuery(document).ready(function(){

	jQuery("#continue_button").click(function(e) {

		e.preventDefault();

		var includecardValue = "no";

		if(jQuery("input[name='includecard']").attr('checked','checked')) {

			includecardValue = "yes";
		
		}

		jQuery("input[name='includecardghost']").val(includecardValue); 
		jQuery("#msgboardedit").submit();
	
	});
	
	jQuery('#addimage2comment').click(function(e){
	
		e.preventDefault();
		var imgURL=prompt("Enter Image URL","http://");
		if(imgURL.length > 9) {
		jQuery("textarea[name='desc']").val(jQuery("textarea[name='desc']").val()+"<img src='"+imgURL+"' />");
		}
	});
	
	jQuery('#addlink2comment').click(function(e){
	
		e.preventDefault();
		var imgURL=prompt("Enter Link URL","http://");
		if(imgURL.length > 9) {
		jQuery("textarea[name='desc']").val(jQuery("textarea[name='desc']").val()+"<a href='"+imgURL+"'>"+imgURL+"</a>");
		}
	});

});