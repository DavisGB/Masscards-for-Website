jQuery(document).ready(function(){
	if(jQuery('.checker').html()=="None") {
	
		//no designs
		jQuery('.container').html("<h4>No designs found for this category</h4>");
		jQuery('.container').append("<a class='goback2category' href='categories.php'>Click here to pick a different category</a>");
	
	} else {

		jQuery('a.lightbox').lightBox();
	}
	
});