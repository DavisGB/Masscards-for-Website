jQuery(document).ready(function(){

	jQuery('.a-image-thumb').lightBox();

	jQuery('#addcategory-button').click(function(e){
	
		e.preventDefault();
		if(jQuery("input[name$='image']").val().length == 0){
			jQuery(".errormsg").html("Make sure you have selected an image to upload");
		} else if(jQuery("input[name$='name']").val().length == 0 || jQuery("textarea[name$='desc']").val().length == 0){
			jQuery(".errormsg").html("Enter a name and description");
		}else {
			jQuery('#add').submit();
		}
	});
	
	jQuery('#updatecategory-button').click(function(e){
	
		e.preventDefault();
		
		if(jQuery("input[name$='image']").val().length == 0){
			jQuery("input[name$='imageghost']").val("retain");
		}else{
			jQuery("input[name$='imageghost']").val("change");
		}
		
		if(jQuery("input[name$='name']").val().length == 0 || jQuery("textarea[name$='desc']").val().length == 0){
			jQuery(".errormsg").html("Never leave the name and description blank");
		}else {
			jQuery('#update').submit();
		}
	
	});
	
	jQuery(".created-prompt input").focus(function() {
	
	    $(this).select();
	    
	});
	
});