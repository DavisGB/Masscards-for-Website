jQuery(document).ready(function() {
	$('input, select, textarea').bind('blur', function(event) {
		$('meta[name=viewport]').attr('content', 'width=device-width,initial-scale=1,maximum-scale=1');
		$('meta[name=viewport]').attr('content', 'width=device-width,initial-scale=1,maximum-scale=10');
	});
});