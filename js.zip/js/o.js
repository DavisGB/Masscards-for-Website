jQuery(document).ready(function(){

	jQuery('#desc_parent').css('visibility', 'hidden');

});