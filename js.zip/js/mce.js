jQuery(document).ready(function(){

	 tinyMCE.init({
        mode : "textareas",
		elements: "desc",
		theme : "advanced",
		theme_advanced_toolbar_location : "top",
		theme_advanced_buttons1 : "undo, redo,separator,bold,italic,underline,strikethrough,zoom,separator,forecolor,backcolor,separator,link,unlink",
		theme_advanced_buttons2 : "",
		theme_advanced_buttons3 : ""
	});
});