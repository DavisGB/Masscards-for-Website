jQuery(document).ready(function(){

	
	
	jQuery("#continue_button").click(function(e) {

		e.preventDefault();

		var includecardValue = "no";

		if(jQuery("input[name='includecard']").attr('checked','checked')) {

			includecardValue = "yes";
		
		}

		jQuery("input[name='includecardghost']").val(includecardValue); 
		jQuery("#msgboardedit").submit();
	
	});
	
	jQuery("#creator").click(function(){
	
			jQuery(".ff").removeAttr('disabled');
			jQuery('#desc_parent').css('visibility', 'visible');
			
	});
	
	jQuery('#ender').click(function(){
	
		jQuery(".ff").attr('disabled', 'disabled');
		jQuery('#desc_parent').css('visibility', 'hidden');
		
	});
	
});