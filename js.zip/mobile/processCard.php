<?php

	require_once('../impt.php');
	require_once('../fpdf.php');
	
	//get design_id
	$design_id = $_GET['design'];
	$compressedHeight = $_GET['cheight'];
	$compressedWidth = $_GET['cwidth'];
	$origHeight = $_GET['oheight'];
	$origWidth = $_GET['owidth'];
	$cat = $_GET['cat'];
        $sid = $_GET['sid'];
	
	if($design_id) {
			
		//get original height and width
		mysql_connect($server,$username,$password);
					
		@mysql_select_db($database) or die( "Unable to select database");
					
		$query="SELECT * FROM mc_designs WHERE id=".$design_id;
		$result=mysql_query($query);
					
		$num=mysql_numrows($result);
		
		if($num>0) {
			//get design image url
			$imageURL = mysql_result($result,0,"thumb_url");
			$designName = mysql_result($result,0,"name");
			$imageUrl = "../".$imageURL;
		
			//get fields from database and get parameters
			$fieldArray = array();
			$arrayPointer = 0;
			
			$query="SELECT * FROM mc_fields WHERE design_id=".$design_id;
			$result=mysql_query($query);
					
			$num=mysql_numrows($result);
			
			if($num>0) {
			
				//make paper size same as original card size
				$pdf=new FPDF('P', 'mm', array(convert($origWidth), convert($origHeight)));
				$pdf->AddPage();
				$pdf->Image($imageURL,0,0, convert($origWidth), convert($origHeight));
				
				
				$i=0;
				while($i<$num) {
					$fieldName = mysql_result($result,$i,"name");
					$xCoord = mysql_result($result,$i,"x_coord");
					$yCoord = mysql_result($result,$i,"y_coord");
					$width = mysql_result($result,$i,"width");
					$used = mysql_result($result,$i,"used");
					
					if($used == "1") {
						//get field from GET parameter
						$fieldArray[$arrayPointer] = stripslashes($_GET[$fieldName]);
						$fieldArray[$arrayPointer] = str_replace("&#38;","&",$fieldArray[$arrayPointer]);
						$fieldArray[$arrayPointer] = str_replace("<br>","\n",$fieldArray[$arrayPointer]);
						
						//xCoord and yCoord needs ratio and proportion (orignal card size and compressed size)
						$xMultiplier = intVal($origWidth)/intVal($compressedWidth);
						$yMultiplier = intVal($origHeight)/intVal($compressedHeight);
						$xFinal = $xCoord*$xMultiplier;
						$yFinal = $yCoord*$yMultiplier;
						
						//add value to pdf
						
						$fontsize = (intVal($origHeight)*intVal($origWidth)*9.5)/500000;
						if($fontsize<12) {
							$fontsize = 12;
						} else if($fontsize>30) {
							$fontsize = 30;
						}
						
						$pdf->SetFont('Times','B',$fontsize);
						
						//apply little magic fix
						$x_cheatfix = $xMultiplier*($fontsize*1.2);
						if($fontsize > 28) {
							$x_cheatfix = $xMultiplier*($fontsize*2.2);
						}
						$y_cheatfix = $yMultiplier*($fontsize*0.8);
						
						$stringWidth = $pdf->GetStringWidth($fieldArray[$arrayPointer]); 
						$start = (convert($width) - $stringWidth)/2; 
						//$fontsize = (intVal($origHeight)*intVal($origWidth)*12)/370000;
						$pdf->SetFont('Times','B', $fontsize);
						//$pdf->Text(convert($xFinal+$x_cheatfix)+$start,convert($yFinal+$y_cheatfix),$fieldArray[$arrayPointer]);
						//$pdf->SetXY(convert($xFinal+$x_cheatfix)+$start, convert($yFinal+$y_cheatfix));
						$pdf->SetXY(convert($xFinal), convert($yFinal));
						$pdf->Multicell(convert(($origWidth*$width)/$compressedWidth),$fontsize/2.75,$fieldArray[$arrayPointer], 0, "C");
						$arrayPointer++;
					}
					
					$i++;
				}
				$i=0;
				
				//add to database
				mysql_query("INSERT INTO mc_masscards (design_id, deleted) VALUES ('".$design_id."', FALSE)");
				$currentId = mysql_insert_id();
				
				//create image name from design name and masscard entry id
				//make design name url friendly
				$designName = str_replace(" ", "_", $designName);
				$imageName = $designName."".$currentId;
				
				mysql_query("UPDATE mc_masscards SET name='".$imageName."' WHERE id=".$currentId); 
				mysql_query("UPDATE mc_masscards SET img_url='cards/".$imageName.".pdf' WHERE id=".$currentId); 	
				
				//save to server
				$pdfcode = $pdf->Output("../cards/".$imageName.".pdf", "F");
				//uncomment below to let user see pdf
				//$pdf->Output();
				
				//redirect to confirm page
				header( "Location: previewCard.php?design=".$design_id."&card=".$currentId."&cat=".$cat."&sid=".$sid );
				
			} else {
				//no fields found
				echo "<div class='nodesign'>YES</div>";
				header( "Location: error.php");
			
			}
			
		} else {
			//design not found
			echo "<div class='nodesign'>YES</div>";
			header( "Location: error.php");
		
		}
		
	} else {
		//design parameter not passed
		echo "<div class='nodesign'>YES</div>";
		header( "Location: error.php");

	}
?>