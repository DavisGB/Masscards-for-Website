<?php
	require_once('../impt.php');
	            
	mysql_connect($server,$username,$password);
	
	@mysql_select_db($database) or die( "Unable to select database");

	if(valid_session($_REQUEST["sid"])) {
            $sid = $_REQUEST["sid"];
            $current_url = $_url = "http://" . $_SERVER['SERVER_NAME']. $_SERVER['REQUEST_URI']; 
            update_session($sid, 6, $current_url);
        } else {
             header("location:expired.php");
        }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Mass Cards | Email</title>
        <meta name = "viewport" content = "width=device-width, initial-scale=1,
 maximum-scale=10" />
        <link href="../css/mobile.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/outputCard.js"></script>
	<script type="text/javascript" src="../js/mobile.js"></script>
    </head>
    <body>
   	<div class="body-wrapper">
   		<center><img id="phjlogo" src="../phjesuitslogo.png" /></center>
   		<div class="container">
   			<div id="mobilecheck" style="display: none;">1</div>
   			<div class="page-help">
   				<span class="help-title">Step 6 of 6</span>
   				<p>Email your card</p>
   			</div>
   			<div class="content-container">
   				<?php
				
				$design_id = $_GET['design']; 
				$card_id = $_GET['card'];
				$board_id = $_GET['board'];
				
				
				if($design_id && $card_id) {
				
					$query="SELECT * FROM mc_masscards WHERE id=".$card_id;
					$result=mysql_query($query);
					
					$num=mysql_numrows($result);
					
					if($num>0) {
					
						$imageURL = mysql_result($result,0,"img_url");
						
						echo "<div class='confirm_details' style='float: none;'>";
						//echo "<p class='intro'>";
						//echo "Your card is viewable at the link below. ";
						//echo "When you click it you will be forced out of this page, so it is important that you open the link in a new tab or window, or just press the back button of your browser.";
						//echo "</p>";
						//echo "<p><a class='link pdflink' id='thepdf' href='".$imageURL."'>Click here to see your card [PDF Format]</a></p>";
						echo "<p></p>";
						//echo "<p><a class='link' href='customizeDesign.php?design=".$design_id."'>Or click here to re-edit your card</a></p>";
						
						//echo "<br />";
						//echo "<p class='intro'>Know that you can send this card in an email to people that you know. Additionally, you can create a custom personal message board about the card for people to comment on.</p>";
						
						echo "<div class='custompage mobile-custompage'>";
						
						//form
						echo "<form id='customconfirm' action='end.php' method='POST'>";
						echo "<br /><p class='label'>Enter your full name:</p>";
						echo "<p><input type='text' name='sender' style='width: 95%;' /></p>";
						echo "<br /><p class='label'>Enter your email address:</p>";
						echo "<p><input type='text' name='email' style='width: 95%;' /></p>";
						echo "<br /><p class='label'>Send this Mass card to (please enter at least one email address):</p>";
						echo "<p><textarea name='recipients' style='width: 95%;'></textarea><br /><span class='note'>*Use spaces to separate multiple email addresses.</span></p>";
						echo "<br /><p class='label'>Write a short message that will be sent with your Mass card:</p>";
						echo "<p><textarea name='msg' style='width:  95%; height: 250px;'></textarea><br /></p>";
						echo "<p><input style='display: none' type='checkbox' name='makeboard' value='yes' checked='true' /> <span style='display: none;' class='checkboxlabel'>Make a personal message board for them to comment on</span></p>";
						echo "<p style='display: none'><input name='card' type='text' value='".$card_id."' /></p>";
						echo "<p style='display: none'><input name='imageURL' type='text' value='".$imageURL."' /></p>";
						echo "<p style='display: none'><input name='board' type='text' value='".$board_id."' /></p>";
						echo "<p style='display: none'><input name='makeboardghost' type='text' value='' /></p>";
						echo "</form>";
						echo "<p><span class='alertmsg'></span></p>";
						echo "</div>"; //email and custom page
						echo "</div>"; //confirm_details
					
					} else {
					
						//mass card not found
						header( "Location: error.php");
					
					}
				
				} else {
				
					//no design_id or card_id
					header( "Location: error.php");
				
				}
			
			?>
				<div style="clear: both;"></div>
			</div>
   		</div>
   		<?php
   		echo "<a id='continue_button' class='mobile-button green' href='#'>CONTINUE TO THE NEXT STEP</a>";
		?>
   	</div>
    </body>
</html>