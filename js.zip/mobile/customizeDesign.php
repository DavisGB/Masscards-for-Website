<?php
	require_once('../impt.php');
	            
	mysql_connect($server,$username,$password);
	
	@mysql_select_db($database) or die( "Unable to select database");

	if(valid_session($_REQUEST["sid"])) {
            $sid = $_REQUEST["sid"];
            $current_url = $_url = "http://" . $_SERVER['SERVER_NAME']. $_SERVER['REQUEST_URI']; 
            update_session($sid, 3, $current_url);
        } else {
             header("location:expired.php");
        }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Mass Cards | Customize</title>
        <meta name = "viewport" content = "width=device-width, initial-scale=1,
 maximum-scale=10" />
        <link href="../css/customizeDesign.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
        <link href="../css/mobile.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/design-checker.js?<?php echo date('l jS \of F Y h:i:s A'); ?>"></script>
    </head>
    <body>
   	<div class="body-wrapper">
   		<center><img id="phjlogo" src="../phjesuitslogo.png" /></center>
   		<div class="container">
   			<div id="mobilecheck" style="display: none;">1</div>
   			<div class="page-help">
   				<span class="help-title">Step 3 of 6</span>
   				<p>Click on the input boxes, and enter the required information. Please make sure to fill in both boxes.</p>
   			</div>
   			<div class="editor">
			<?php
				
				
				$design_id = $_GET['design'];
				$cat_id = $_GET['cat'];
				
				if(!$design_id) {
				
					echo "<div class='checker' style='display: none'>None</div>";
				
				}
				
				
				$query="SELECT * FROM mc_designs WHERE id=".$design_id;
				$result=mysql_query($query);
				
				$num=mysql_numrows($result);
				
				if($num==0) {
				
					echo "<div class='checker' style='display: none'>None</div>";
				
				}
				
				$i=0;
				while($i<$num) {
					
					$id=mysql_result($result,$i,"id");
					$name=mysql_result($result,$i,"name");
					$description=mysql_result($result,$i,"description");
					$deleted=mysql_result($result,$i,"deleted");
					$thumb_url=mysql_result($result,$i,"thumb_url");
					
					if($deleted == "0") {
					
						echo "<div class='imgholder'><img src='../".$thumb_url."' /></div>";
						echo "<img class='origImage'  src='../".$thumb_url."' />";
						echo "<p style='display: none;' class='cat'>".$cat_id."</p>";
					
					}
					
					$i++;
				
				}
				$i=0;
				
				if($num != 0) {
					//get fields
						
					echo "<div class='fields'>";
                                        echo "<div class='sid'>".$sid."</div>";	
					echo "<div class='desid'>".$design_id."</div>";	
					
						$query="SELECT * FROM mc_fields WHERE design_id=".$design_id;
						$result=mysql_query($query);
				
						$num=mysql_numrows($result);
						
						$i=0;
						while($i<$num){
						
							$id=mysql_result($result,$i,"id");
							$name=mysql_result($result,$i,"name");
							$x_coord=mysql_result($result,$i,"x_coord");
							$y_coord=mysql_result($result,$i,"y_coord");
							$width=mysql_result($result,$i,"width");
							$height=mysql_result($result,$i,"height");
							$used=mysql_result($result,$i,"used");
								
						
							if($used == "1") {
								
								echo "<div class='field' name='".$name."' x='".$x_coord."' y='".$y_coord."' width='".$width."' height='".$height."'></div>";
							}
							$i++;
						}
						$i=0;
						
					echo "</div>";
				
				}
						
				mysql_close();
			?>
			</div>
			<div style='clear: both'></div>
   		</div>
   		<a id='continue_button' class='mobile-button green' href='#'>CONTINUE TO THE NEXT STEP</a>
   		<a href="design.php?cat=<?php echo $cat_id;?>&sid=<?php echo $sid;?>" class="mobile-button red">
			Go back to Previous Step
		</a>
   	</div>
    </body>
</html>