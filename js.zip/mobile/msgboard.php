<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns:fb="http://www.facebook.com/2008/fbml">
	<?php
	
		require_once('../impt.php');
		
		//require_once('recaptchalib.php');
		require '../facebook.php';
		
		$publickey = "6LeJ7OMSAAAAAKrRG0yYCVTq7-6UGcVRbuCBNqM2";

		// Create our Application instance (replace this with your appId and secret).
		$facebook = new Facebook(array(
		  'appId'  => '221293564548094',
		  'secret' => '5e9d0ba8f5d9a9f07a638db2bc876669',
		  'cookie' => true,
		  'domain' => $siteURL
		));

		// We may or may not have this data based on a $_GET or $_COOKIE based session.
		//
		// If we get a session here, it means we found a correctly signed session using
		// the Application Secret only Facebook and the Application know. We dont know
		// if it is still valid until we make an API call using the session. A session
		// can become invalid if it has already expired (should not be getting the
		// session back in this case) or if the user logged out of Facebook.
		$session = $facebook->getSession();

		$me = null;
		// Session based API call.
		if ($session) {
		  try {
			$uid = $facebook->getUser();
			$me = $facebook->api('/me');
			$friends = $facebook->api('/me/friends');
		  } catch (FacebookApiException $e) {
			error_log($e);
		  }
		}
		else
		{
		$url = $facebook->getLoginUrl(array(
					   'canvas' => 1,
					   'fbconnect' => 0,
					   'req_perms' => "publish_stream"
				   ));
		 
			//echo "<a href='$url'>Click here</a>";

		}
		
		$board_id = $_REQUEST['board'];
		
		mysql_connect($server,$username,$password);			
		@mysql_select_db($database) or die( "Unable to select database");
	
		$query="SELECT * FROM mc_boards WHERE id=".$board_id;
		$result=mysql_query($query);
	
		$num=mysql_numrows($result);
					
		if($num>0) {
		
			$title = mysql_result($result,0,"title");
			$desc = mysql_result($result,0,"description");
			$masscard_id = mysql_result($result,0,"masscard_id");
			$include_card = mysql_result($result,0,"include_card");
			$image_attach = mysql_result($result,0,"image_attach");
			$deleted = mysql_result($result,0,"deleted");
			
			echo "<head>";
			echo "	<title>".$title."</title>";
			echo '	<meta name = "viewport" content = "width=device-width, initial-scale=1,
 maximum-scale=10" />';
			echo "		<link href='../css/msgboard.css?".date('l jS \of F Y h:i:s A')."' rel='stylesheet' type='text/css' />";
			echo "		<link href='../css/jquery.realperson.css?".date('l jS \of F Y h:i:s A')."' rel='stylesheet' type='text/css' />";
			echo "		<link href='../css/mobile.css?".date('l jS \of F Y h:i:s A')."' rel='stylesheet' type='text/css' />";
			echo "		<script type='text/javascript' src='../js/jquery.js'></script>";
			echo "		<script type='text/javascript' src='../js/msgboard.js'></script>";
			echo "		<script type='text/javascript' src='../js/tiny_mce/tiny_mce.js'></script>";
			echo "		<script type='text/javascript' src='../js/jquery.realperson.js'></script>";
			echo "		<script type='text/javascript'>$(document).ready(function() { $('#defaultReal').realperson(); });</script>";
			echo "		<script type='text/javascript' src='../js/mobile.js'></script>";
			echo "</head>";
			echo "<body>";
			echo '<center><img id="phjlogo" src="../phjesuitslogo.png" /></center>';
   			echo '<div class="container">';
   			echo '<div id="mobilecheck" style="display: none;">1</div>';
   			echo '<div class="content-container" style="float: none;">';
			
			if($deleted == "0") {
				$query="SELECT * FROM mc_masscards WHERE id=".$masscard_id;
				$result=mysql_query($query);
		
				$imageURL = mysql_result($result,0,"img_url");
				$deleted = mysql_result($result,0,"deleted");
		
				
				echo "<span class='title' style='font-size: 15px !important; display: block; text-align: center;'>".$title."</span><br />";
				
				if(strlen($image_attach)>10) {
					echo "<br /><img src='image.php?width=400&amp;image=/masscards/".$image_attach."'><br />";
					echo "<div style='display: none' id='image-fb-share'>http://phjesuits.org/masscards/".$image_attach."</div>";

				}
				
				echo "<br /><br /><div class='desc'>".$desc."</div><br /><br />";
				
				
				?>
				
				<div id="fb-root"></div>
				<script>
				  window.fbAsyncInit = function() {
					FB.init({
					  appId   : '<?php echo $facebook->getAppId(); ?>',
					  session : '<?php echo json_encode($session); ?>', // don't refetch the session when PHP already has it
					  status  : true, // check login status
					  cookie  : true, // enable cookies to allow the server to access the session
					  xfbml   : true // parse XFBML
					});
			 
				  };

				  (function() {
					var e = document.createElement('script');
					e.src = document.location.protocol + '//connect.facebook.net/en_US/all.js';
					e.async = true;
					document.getElementById('fb-root').appendChild(e);
				  }());
				
				</script>

				
			
		<?php
				
				echo "<h2 style='text-align: center; font-size: 15px;'>Tributes</h2>";
				/*e
				cho "<script>";
				echo "var idcomments_acct = '1d53b67fab2a927d8654d7be8af8e67a';";
				echo "var idcomments_post_id;";
				echo "var idcomments_post_url;";
				echo "</script>";
				echo "<span id='IDCommentsPostTitle' style='display:none'></span>";
				echo "<script type='text/javascript' src='http://www.intensedebate.com/js/genericCommentWrapperV2.js'></script>";
				
				echo "<a href='#' id='addimage2comment' class='goback2category' style='margin-left: 0px; display: inline;'>Add Image to comment box</a> <a href='#' id='addlink2comment' class='goback2category' style='margin-left: 30px; display: inline;'>Add Link to comment box</a>";
				*/
				
				echo "<div id='tributeholder'>";
				
				echo "<form id='postTribute' method='POST' action='addTribute.php'>";
				echo "<p><b style='font-size: 13px;'>Your Name:</b> <input class='tribute_author' name='author'style='font-size: 13px; width: 95%;' /><br /><textarea id='tribute_content' name='tribute' class='tribute_content' style='margin-top: 12px; width: 97%; font-size: 13px;'></textarea></p>";
				echo "<p style='display: none;'><input name='board' value='".$board_id."' /></p>";
				
				if($_GET["e"] == "1") {
					echo "<p style='color: red;'>You've entered the wrong letters. Pls try again</p>";
				}
				
				echo '<p><label style="font-size: 13px;">Please enter the letters displayed:<div style="display: block; width: 100%; height: 1px;"></div></label>
		<input type="text" id="defaultReal" name="defaultReal" style="font-size: 13px;display: block; margin-top: 5px; margin-bottom: 20px;" ></p>';
				echo "</form>";
				echo "<br /><div class='publish'><a class='goback2category publish_btn mobile-button' id='publish_button' style='background: #4682B4; font-size: 13px; display: block; width: 100%; padding: 10px 0; ' href='#'>Publish</a></div>";
				
				$query2="SELECT * FROM mc_tributes WHERE board_id=".$board_id;
				$result2=mysql_query($query2);
				
				$num2=mysql_numrows($result2);
				
				$i2=0;
				while($i2<$num2) {
				
					$id=mysql_result($result2,$i2,"id");
					$author=mysql_result($result2,$i2,"author");
					$tribute=mysql_result($result2,$i2,"content");
					$deleted=mysql_result($result2,$i2,"deleted");
					$date_created=mysql_result($result2,$i2,"date_created");
					
					if($deleted == "0") {
					
						echo "<div class='tributo' style='width: 100%;'>";
						echo "<p class='awtor' style='font-size: 13px;'>".$author." says: </p>";
						echo "<div style='font-size: 13px;'>".stripslashes($tribute)."</div>";
						echo "<p class='petsa' style='font-size: 9px;'>".$date_created."</p>";
						echo "</div>";
					}
					$i2++;
				}
				
				echo "<div style='clear: both;'></div>";
				echo "</div>";
				
				echo "<form id='publishToFB' method='POST' action='publishToFB.php'>";
				echo "<p style='display: none;'><input type='text' name='boardLink' value='".$siteURL."msgboard.php?board=".$board_id."' /></p>";
				echo "</form>";
				
				echo "<div style='text-align:center; margin-top: 100px;'>";
				if(true) {
					//echo "<br /><br /><object type='application/pdf' data='".$imageURL."' width='100%' height='100%' < >/object >";
					//echo "<iframe src='http://docs.google.com/gview?url=".$siteURL.$imageURL."&embedded=true' style='width:700px; height:550px;' frameborder='0'></iframe>";
					echo "<span style='font-size: 12px;'>This online tribute board was created when a Mass card was sent from <a href='http://www.phjesuits.org' style='text-decoration: none; color: red;'>www.phjesuits.org</a>.</span><br />";
					echo "<a href='".$imageURL."' class='goback2category pdflink mobile-button' id='thepdf' style='background: #4682B4; font-size: 13px; display: block; width: 100%; padding: 10px 0; '>View the Mass card here</a><br /><br />";
				}
				//echo "</div><b>Share this online tribute board:</b><br/>";
				//echo "<input id='share' class='sharelink' value='".$siteURL."msgboard.php?board=".$board_id."' />";
				//echo "<span class='sharelinkghost'>".$siteURL."msgboard.php?board=".$board_id."</span>";
				//echo "<br/><span class='note'>*Click on the link above to select it, then copy and email it to your friends.</span><br /><br />";
				
			?>	
			
			
			
			<?php
				echo "<div style='clear: both;'></div>";
				echo "</div>";
			}
			
			
			echo "</div>";
			echo "</body>";
		
		} else {
			
			//board not found
			header( "Location: error.php");
		
		}
	
	?>
</html>