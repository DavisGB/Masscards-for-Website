<?php

	require_once('../impt.php');

	$sender = $_POST['sender'];
	$recipients = $_POST['recipients']; 
	$msg = $_POST['msg'];
	$card = $_POST['card'];
	$usrEmail = $_POST['email'];
	$imageURL = $_POST['imageURL'];
	$makeboardghost = $_POST['makeboardghost'];
	$board_id = $_POST['board'];
	$makeboard = "";
	
	mysql_connect($server,$username,$password);
				
				@mysql_select_db($database) or die( "Unable to select database");
				
	
	if(isset($_POST['makeboardghost']) && isset($_POST['email']) && isset($_POST['imageURL'])) {
	
		//insert donator in database
		mysql_query("INSERT INTO mc_donator (donator, email, img_url) VALUES ('".$sender."', '".$usrEmail."', '".$imageURL."')");
					
		if($board_id != "na") {
					
			$makeboard = "yes";
					
		} else {
					
			$makeboard = "no";
			//redirect to end page
			//header( "Location: ".$siteURL."end.php?thumb=".$imageURL."");
						
		}
		
		$emailmsg = "";
					$intromsg = "";
					$boardEdits = "";
					
					if($makeboard == "yes") {
						//create message board and add to database
						//mysql_query("INSERT INTO mc_boards (title, description, masscard_id, include_card, deleted) VALUES ('An online tribute to INSERT NAME HERE', 'This mass card is brought to you by phjesuits.org', ".$card.", TRUE, FALSE)");
						//$board_id = mysql_insert_id();
					
						$emailmsg = "An online tribute board has also been created. Visit it here: ".$siteURL."msgboard.php?board=".$board_id;
						$intromsg = " and an online tribute board has also been created. A link to this board is provided below. To make changes to this tribute board, edit the values located in the link after this paragraph.";
						$boardEdits = "To make changes to this online tribute board, go to: ".$siteURL."editBoard.php?board=".$board_id."";
					}
		
		if($recipients != "") {
						//separate recipients
						$recipientArray = explode(" ",$recipients);
						
						if($recipientArray) {
							$i=0;
							while($i<count($recipientArray)){
							
								$to = $recipientArray[$i];
								$subject = "A Mass Card from the Philippine Jesuits (www.phjesuits.org)";
								$body = "Peace. We wish to inform you that ".$sender." has sent you a Mass card.\nThe Philippine Jesuits will offer the Holy Sacrifice of the Mass for the intention stated on this card.\n\nA message from your loved one is attached below:\n\n".$msg."\n\nYou can view the Mass card here: ".$siteURL.$imageURL."\n\n".$emailmsg."\n\nYou, too, can send Mass cards and create online tribute boards for your loved ones. Visit www.phjesuits.org, and look for Mass Cards Online.";
								//$headers .= "Reply-To: Philippine Jesuits <webmaster@phjesuits.org>\r\n"; 
								//$headers .= "Return-Path: Philipine Jesuits <webmaster@phjesuits.org>\r\n"; 
								$headers .= "From: Philippine Jesuits <phjesuits@justhost.com>\r\n"; 
								//BCC: berna.pjaa@gmail.com, philjesuitaid@yahoo.com, phjesuits@gmail.com
								$headers .= "Organization: My Organization\r\n"; 
								$headers .= "Content-Type: text/plain\r\n"; 
								
								//uncomment to mail recipients
								//mail($to, $subject, stripslashes($body), $headers);
								
								$i++;
							}
							$i=0;
							
							$to = "berna.pjaa@gmail.com, philjesuitaid@yahoo.com, phjesuits@gmail.com";
							$subject = "BCC: A Mass Card from the Philippine Jesuits (www.phjesuits.org)";
							$body = "Peace. We wish to inform you that ".$sender." has sent you a Mass card.\nThe Philippine Jesuits will offer the Holy Sacrifice of the Mass for the intention stated on this card.\n\nA message from your loved one is attached below:\n\n".$msg."\n\nYou can view the Mass card here: ".$siteURL.$imageURL."\n\n".$emailmsg."\n\nYou, too, can send Mass cards and create online tribute boards for your loved ones. Visit www.phjesuits.org, and look for Mass Cards Online.";
							//$headers .= "Reply-To: Philippine Jesuits <webmaster@phjesuits.org>\r\n"; 
							//$headers .= "Return-Path: Philipine Jesuits <webmaster@phjesuits.org>\r\n"; 
							$headers .= "From: Philippine Jesuits <phjesuits@justhost.com>\r\n"; 
							$headers .= "Organization: My Organization\r\n"; 
							$headers .= "Content-Type: text/plain\r\n"; 
							
							//uncomment to mail recipients
							mail($to, $subject, stripslashes($body), $headers);
						}
					}
		
		if(isset($usrEmail)){
					
						$to = $usrEmail;
						$subject = "Your Mass Card is now online.";
						$body = "The card can be found at: ".$siteURL.$imageURL."\n\nThe link above has also been forwarded to the email addresses you specified, along with a link to an online tribute board (if you created one).\n\nYou can print your Mass card, and give it personally. Click on the link above, or copy and paste it in your web browser's address bar. While viewing the card, click on FILE then PRINT (for Internet Explorer, Mozilla Firefox, and Safari), or click on the wrench icon then PRINT (for Google Chrome). Make sure to adjust your printer's settings to print in landscape format. Depending on your printer's settings, you can also scale the Mass card to fit the page.\n\n".$emailmsg."\n\n".$boardEdits;
						$headers .= "Reply-To: PHJesuits <webmaster@phjesuits.org>\r\n"; 
						$headers .= "Return-Path: PHJesuits <webmaster@phjesuits.org>\r\n"; 
						$headers .= "From: PHJesuits <phjesuits@justhost.com>\r\nBCC: berna.pjaa@gmail.com, philjesuitaid@yahoo.com, phjesuits@gmail.com"; 
						$headers .= "Organization: My Organization\r\n"; 
						$headers .= "Content-Type: text/plain\r\n"; 
								
						//uncomment to mail recipients
						mail($to, $subject, stripslashes($body), $headers);
					
					}
	
	}
	

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Mass Cards</title>
        <meta name = "viewport" content = "width=device-width, initial-scale=1,
 maximum-scale=10" />
        <link href="css/boardEditor.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
        <link href="../css/mobile.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/msgboard.js"></script>
	<script type="text/javascript" src="../js/boardEditor.js?<?php echo date('l jS \of F Y h:i:s A'); ?>"></script>
	<script type='text/javascript' src='../js/tiny_mce/tiny_mce.js'></script>
	<script type='text/javascript' src="../js/mce.js?<?php echo date('l jS \of F Y h:i:s A'); ?>"></script>
    </head>
    <body>
   	<div class="body-wrapper">
   		<center><img id="phjlogo" src="../phjesuitslogo.png" /></center>
   		<div class="container">
   			<div id="mobilecheck" style="display: none;">1</div>
   			<div class="page-help">
   				<span class="help-title">Thank you very much!</span>
   			</div>
   			<div class="content-container">
   				<?php
					
					echo "<p><b>An email with a link to the card you created was sent to:</b></p>";
					if($recipients != "") {
						//separate recipients
						$recipientArray = explode(" ",$recipients);
						
						if($recipientArray) {
							$i=0;
							while($i<count($recipientArray)){
							
								$to = $recipientArray[$i];
								
								echo $to."<br />";
								
								
								$i++;
							}
							$i=0;
						}
					}
					echo "<br />";
					
					echo "<b>This email contains the following message:</b><br />";
					echo "<p>".$msg."</p>";
					
					if($makeboard == "yes"){
					
						echo "<b>Copy the link below, and email it to your friends so that they can start posting on your online tribute board.</b><br />";
						echo "<input type='text' class='sharelink' style='width: 350px;' value='".$siteURL."msgboard.php?board=".$board_id."' />";
						
						echo "<br />";
						echo "<p><a style='text-decoration: none;' href='msgboard.php?board=".$board_id."'>Click here to visit your online tribute board.</a></p>";
						echo "<p><a style='text-decoration: none;' href='../".$imageURL."' target='_blank' >Click here to view your Mass Card.</a></p>";
					
					}else{
						echo "<p><a style='text-decoration: none;' href='../".$imageURL."' target='_blank' >Click here to view your Mass Card.</a></p>";
					}
				
				?>
	
			<p></p>
			<p></p>
		    <p><br>
              <br>
            <span class="style1"><strong>Please check your email in 5 to 10 minutes. <br />
            If you don't see any email from us in your inbox, please check your spam folder.<br />
            Please tell the people to whom you sent the Mass card to check their spam folders as well. </strong></span></p>
		    <p><span class="style1"><strong>You can print your Mass card, and give it personally.</strong><br />
            Follow the link to your Mass card.<br />
        While viewing the card, click on FILE then PRINT (for Internet Explorer, Mozilla Firefox, and Safari),<br />
        or click on the wrench icon then PRINT (for Google Chrome).<br />
        Make sure to adjust your printer's settings to print in landscape format.<br />
        Depending on your printer's settings, you can also scale the Mass card to fit the page.              </span></p>
	
   			</div>
   		</div>
   	
   	</div>
    </body>
</html>