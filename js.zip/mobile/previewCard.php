<?php
	require_once('../impt.php');
	            
	mysql_connect($server,$username,$password);
	
	@mysql_select_db($database) or die( "Unable to select database");

	if(valid_session($_REQUEST["sid"])) {
            $sid = $_REQUEST["sid"];
            $current_url = $_url = "http://" . $_SERVER['SERVER_NAME']. $_SERVER['REQUEST_URI']; 
            update_session($sid, 4, $current_url);
        } else {
             header("location:expired.php");
        }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Mass Cards | Categories</title>
        <meta name = "viewport" content = "width=device-width, initial-scale=1,
 maximum-scale=10" />
        <link href="../css/mobile.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/mobile.js"></script>
    </head>
    <body>
   	<div class="body-wrapper">
   		<center><img id="phjlogo" src="../phjesuitslogo.png" /></center>
   		<div class="container">
   			<div id="mobilecheck" style="display: none;">1</div>
   			<div class="page-help">
   				<span class="help-title">Step 4 of 6</span>
   				<p>If you are satisfied with your card, click on <br/>"CONTINUE TO THE NEXT STEP."<br /><br/>
		    		If you want to make changes, click on <br/>&quot;GO BACK TO THE PREVIOUS STEP.&quot;</p>
   			</div>
   			<div class="content-container">
	   			<?php
					
					$design_id = $_GET['design']; 
					$card_id = $_GET['card'];
					$cat = $_GET['cat'];
					
					if($design_id && $card_id) {
					
						$query="SELECT * FROM mc_masscards WHERE id=".$card_id;
						$result=mysql_query($query);
						
						$num=mysql_numrows($result);
						
						if($num>0) {
						
							$imageURL = mysql_result($result,0,"img_url");
							
							echo "<div class='confirm_details'>";
							echo "<p class='intro'>";
							//echo "Your card is viewable at the link below. ";
							//echo "When you click it you will be forced out of this page, so it is important that you open the link in a new tab or window, or just press the back button of your browser.";
							echo "</p>";
							echo "<p><a class='link pdflink' id='thepdf' href='../".$imageURL."'>CLICK HERE TO PREVIEW YOUR CARD.</a></p>";
							echo "<p></p>";
							
							echo "<br />";
							//echo "<p class='intro'>You can send this card in an email to people that you know. Additionally, you can create a custom personal message board about the card for people to comment on.</p>";
							
							echo "<div class='custompage'>";
							
							echo "</div>"; //email and custom page
							echo "</div>"; //confirm_details
						
						} else {
						
							//mass card not found
							header( "Location: error.php");
						
						}
					
					} else {
					
						//no design_id or card_id
						header( "Location: error.php");
					
					}
				
				?>
			</div>
   		</div>
   		<?php
   		echo "<a class='mobile-button green' href='makeBoard.php?design=".$design_id."&card=".$card_id."&sid=".$sid."'>CONTINUE TO THE NEXT STEP</a>";
   		echo "<a href='customizeDesign.php?design=".$design_id."&cat=".$cat."&sid=".$sid."' class='mobile-button red'>
			Go back to Previous Step
		</a>";
		?>
   	</div>
    </body>
</html>