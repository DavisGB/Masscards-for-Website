<?php
			
	require_once('../impt.php');
				
	$board_id = $_POST['board'];
	$author = $_POST['author'];
	$tribute = $_POST['tribute'];
	
	function rpHash($value) { 
	    $hash = 5381; 
	    //$value = strtoupper($value); 
	    for($i = 0; $i < strlen($value); $i++) { 
	        $hash = (($hash << 5) + $hash);// + ord(substr($value, $i)); 
	    } 
	    
	    
	    return $hash; 
	} 
 
	
	mysql_connect($server,$username,$password);
				
	@mysql_select_db($database) or die( "Unable to select database");
	
	if(isset($board_id) && isset($author) && isset($tribute)){
	
		if ($_POST['defaultReal'] == $_POST['defaultRealHash']) { 
			mysql_query("INSERT INTO mc_tributes (board_id, author, content, deleted) VALUES ('".$board_id."', '".$author."', '".$tribute."', FALSE)");
			header( "Location: ".$siteURL."mobile/msgboard.php?board=".$board_id."");
		} else {
			
			header( "Location: ".$siteURL."mobile/msgboard.php?board=".$board_id."&e=1");
		}
	} else if(isset($author) && isset($tribute)) {
	
		header( "Location: ".$siteURL."mobile/msgboard.php?board=".$board_id."");
		
	} else {
	        
		header( "Location: ".$siteURL."");
			
	}		
?>				