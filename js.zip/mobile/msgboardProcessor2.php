<?php
	
	require_once('../impt.php');

	$title = $_POST['title'];
	$desc = $_POST['desc'];		
	$imageURL = $_POST['imageURL'];
	$includecard = $_POST['includecardghost'];
	$board_id = $_POST['board'];
	$design_id = $_POST['design'];
	$card_id = $_POST['card'];
	$group = $_POST['group'];
	$sid = $_POST['sid'];
	
	if($group == "No"){
		header( "Location: outputCard.php?design=".$design_id."&card=".$card_id."&board=na&sid=".$sid);
	}else{

	//update to database
	mysql_connect($server,$username,$password);			
	@mysql_select_db($database) or die( "Unable to select database");
	
	mysql_query("UPDATE mc_boards SET title='".$title."' WHERE id=".$board_id); 
	mysql_query("UPDATE mc_boards SET description='".$desc."' WHERE id=".$board_id); 
	
	if($includecard == "yes") {
	
		mysql_query("UPDATE mc_boards SET include_card=TRUE WHERE id=".$board_id); 
	
	} else {
	
		mysql_query("UPDATE mc_boards SET include_card=FALSE WHERE id=".$board_id); 
	
	}
	
	if($_FILES['image']['type']!=null){
	
		$query="SELECT SHA('".date('l jS \of F Y h:i:s A')."')";
		$result=mysql_query($query);
	
		$num=mysql_numrows($result);
					
		$hash = mysql_result($result, 0);
		
		$target_path = "images/";
		
		//upload image
		$target_path = $target_path .$hash. basename($_FILES['image']['name']); 
		
		if(move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
			//echo "The file ". basename( $_FILES['image']['name'])." has been uploaded";
		} else{
			//echo "There was an error uploading the file, please try again!";
		}
		
		//then add a new entry to the database
		mysql_query("UPDATE mc_boards SET image_attach='".$target_path."' WHERE id=".$board_id); 
	
	}
	
	//redicrect to send email (outputCard)
	header( "Location: outputCard.php?design=".$design_id."&card=".$card_id."&board=".$board_id."&sid=".$sid);
	}
?>