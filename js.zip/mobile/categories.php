<?php
	require_once('../impt.php');
	            
	mysql_connect($server,$username,$password);
	
	@mysql_select_db($database) or die( "Unable to select database");

	if(strlen($_REQUEST["sid"]) == 0) {
        	$sid = create_session();
        }

        if(valid_session($_REQUEST["sid"]) || valid_session($sid)) {
            
            if(strlen($sid) == 0) {
            	$sid = $_REQUEST["sid"];
            }
            
            $current_url = $_url = "http://" . $_SERVER['SERVER_NAME']. $_SERVER['REQUEST_URI']; 
            update_session($sid, 1, $current_url);
        } else {
             header("location:expired.php");
        }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Mass Cards | Categories</title>
        <meta name = "viewport" content = "width=device-width, initial-scale=1,
 maximum-scale=10" />
        <link href="../css/mobile.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/mobile.js"></script>
    </head>
    <body>
   	<div class="body-wrapper">
   		<center><img id="phjlogo" src="../phjesuitslogo.png" /></center>
   		<div class="container">
   			<div class="page-help">
   				<span class="help-title">Step 1 of 6</span>
   				<p>Click on a category to begin</p>
   			</div>
   			<div class="list-container">
			<?php
			
				$query="SELECT * FROM mc_categories";
				$result=mysql_query($query);
				
				$num=mysql_numrows($result);
				
				$i=0;
				while($i<$num) {
					
					$id=mysql_result($result,$i,"id");
					$name=mysql_result($result,$i,"name");
					$description=mysql_result($result,$i,"description");
					$deleted=mysql_result($result,$i,"deleted");
					$thumb_url=mysql_result($result,$i,"thumb_url");
					
					if($deleted == "0") {
						echo "<div class='list-item'><a href='designs.php?cat=".$id."&sid=".$sid."'>";
						//echo "<td>ID=".$id."</td>";
						echo "<div class='thumb-container'><img class='thumb' src='../".$thumb_url."' /></div>";
						echo "<div class='desc-container'><p class='title'>".$name."<p>";

						echo "<p class='desc'>".$description."</p>";
						//echo "<p>Deleted=".$deleted."</p>";
						echo "</div><div style='clear: both'></div></a>";
						echo "</div>";
					}
					
					$i++;
				
				}
				$i=0;
				
				mysql_close();
			?>
			
				<div style='clear: both'></div>
			</div>
   		</div>
   	</div>
    </body>
</html>