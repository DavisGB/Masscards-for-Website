<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Session Expired</title>
        <meta name = "viewport" content = "width=device-width, initial-scale=1,
 maximum-scale=10" />
        <link href="../css/mobile.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/mobile.js"></script>
    </head>
    <body>
   	<div class="body-wrapper">
   		<center><img id="phjlogo" src="../phjesuitslogo.png" /></center>
   		<div class="container">
   			<div class="page-help">
   				<span class="help-title">Session Expired</span>
   			</div>

   		</div>
   	</div>
    </body>
</html>