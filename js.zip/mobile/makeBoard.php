<?php
	require_once('../impt.php');
	            
	mysql_connect($server,$username,$password);
	
	@mysql_select_db($database) or die( "Unable to select database");

	if(valid_session($_REQUEST["sid"])) {
            $sid = $_REQUEST["sid"];
            $current_url = $_url = "http://" . $_SERVER['SERVER_NAME']. $_SERVER['REQUEST_URI']; 
            update_session($sid, 5, $current_url);
        } else {
             header("location:expired.php");
        }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Mass Cards | Online Board</title>
        <meta name = "viewport" content = "width=device-width, initial-scale=1,
 maximum-scale=10" />
        <link href="../css/outputPage.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
        <link href="../css/mobile.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="../js/jquery.js"></script>
	
	<script type='text/javascript' src='../js/tiny_mce/tiny_mce.js'></script>
	<script type='text/javascript' src="../js/mce.js?<?php echo date('l jS \of F Y h:i:s A'); ?>"></script>
	
	<script type="text/javascript" src="../js/outputCard2.js?<?php echo date('l jS \of F Y h:i:s A'); ?>"></script>
	<script type="text/javascript" src="../js/o.js?<?php echo date('l jS \of F Y h:i:s A'); ?>"></script>
	<script type="text/javascript" src="../js/mobile.js"></script>
    </head>
    <body>
   	<div class="body-wrapper">
   		<center><img id="phjlogo" src="../phjesuitslogo.png" /></center>
   		<div class="container">
   			<div id="mobilecheck" style="display: none;">1</div>
   			<div class="page-help">
   				<span class="help-title">Step 5 of 6</span>
   				<p>Configure your online tribute board</p>
   			</div>
   			<div class="content-container">
   				<p class='intro2' style="width: auto !important; font-size: 13px !important;">Do you want to enable a message wall? Your friends and loved ones can post tributes and pictures on this board to honor the person/s for whom you are offering a Mass. This is a free service provided by the Philippine Jesuits. We will send you a link to this board, and you and your loved ones can visit it for one year starting today. After one year, the board will be disabled.</p>
	   			<?php
			
				
				$design_id = $_GET['design']; 
				$card_id = $_GET['card'];
				
				if($design_id && $card_id) {
				
					$query="SELECT * FROM mc_masscards WHERE id=".$card_id;
					$result=mysql_query($query);
					
					$num=mysql_numrows($result);
					
					if($num>0) {
					
						$imageURL = mysql_result($result,0,"img_url");
						
						mysql_query("INSERT INTO mc_boards (title, description, masscard_id, include_card, deleted) VALUES ('An Online Tribute to ', '', ".$card_id.", TRUE, FALSE)");
						$board_id = mysql_insert_id();
						
						echo "<div class='confirm_details' style='float: none;'>";
						echo "<p class='intro'>";
						//echo "Sample of an online Tribute Board: ";
						//echo "When you click it you will be forced out of this page, so it is important that you open the link in a new tab or window, or just press the back button of your browser.";
						echo "</p>";
						//echo "<p><a class='link pdflink' id='thepdf' href='".$imageURL."'>Click here to see your card [PDF Format]</a></p>";
						echo "<p></p>";
						//echo "<p><a class='link' href='customizeDesign.php?design=".$design_id."'>Or click here to re-edit your card</a></p>";
						
						//echo "<br />";
						//echo "<p class='intro'>Know that you can send this card in an email to people that you know. Additionally, you can create a custom personal message board about the card for people to comment on.</p>";
						
						echo "<div class='custompage'>";
						
						//form
						echo "<form  enctype='multipart/form-data' id='msgboardedit' action='msgboardProcessor2.php' method='POST'>";
						
						echo "<input type='hidden' name='sid' value=".$sid.">";
						echo "<input id='creator' type='radio' name='group' value='Yes'><span style='font-size: 13px; margin-left: 7px;'>Yes, please set up this FREE online tribute board!</span><br><br/>";
						echo "<input id='ender' type='radio' name='group' value='No' checked><span style='font-size: 13px; margin-left: 7px;'>No need. Thank you for the offer.</span><br>";
						echo "<br /><br/><p class='label'>Your Message Board Details</p><br/>";
						
						echo "<p class='label'>Title:</p>";
						echo "<p><input class='title ff' disabled='disabled' name='title' style='width: 90%; font-size: 13px; padding: 3px 5px; border: 1px solid #BBB;' value='An Online Tribute to (INSERT NAME/S HERE)' /><br /></p>";
						echo "<p class='label'>Write a short description or an introductory message for your message board:</p>";
						echo "<p><textarea id='desc' class='ff' disabled='disabled' name='desc'></textarea>";
						
						echo "</p>";
						echo "<br />";
						echo "<p style='font-size: 13px;' >You can upload an image to display on your comment board. This image can be a picture of the person/s this mass card is for. Click on Choose File.<br /><span style='color: red;'>Note: If you do not have an image right now, you can upload an image later. In the email we will send you shortly, we will include a link that will allow you to edit your online tribute board.</span></p>";
						echo "<input type='hidden' name='MAX_FILE_SIZE' value='2000000' />";
						echo "<p><input name='image' type='file' class='ff' disabled='disabled' style='font-size: 13px; height: 50px; display: inline-block;' /> </p>";
						echo "<br /><br />";
						echo "<p style='display: none'><input name='board' type='text' value='".$board_id."' /></p>";
						echo "<p style='display: none'><input name='imageURL' type='text' value='".$imageURL."' /></p>";
						echo "<p style='display: none'><input name='design' type='text' value='".$design_id."' /></p>";
						echo "<p style='display: none'><input name='card' type='text' value='".$card_id."' /></p>";
						echo "<p style='display: none'><input name='includecardghost' type='text' value='yes' /></p>";
						
						echo "</form>";
						echo "<p><span class='alertmsg'></span></p>";
						echo "</div>"; //email and custom page
						
						
						
						
						
						
						echo "</div>"; //confirm_details
					
					} else {
					
						//mass card not found
						header( "Location: error.php");
					
					}
				
				} else {
				
					//no design_id or card_id
					header( "Location: error.php");
				
				}
			
			?>
				<div style="clear: both;"></div>
			</div>
   		</div>
   		<?php
   		echo "<a id='continue_button' class='mobile-button green' href='makeBoard.php?design=".$design_id."&card=".$card_id."&sid=".$sid."'>CONTINUE TO THE NEXT STEP</a>";
		?>
   	</div>
    </body>
</html>